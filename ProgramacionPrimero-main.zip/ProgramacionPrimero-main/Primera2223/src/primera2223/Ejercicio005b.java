/*
 Mostrar por pantalla si un número es par o impar, este ha sido el 
ejericicio resulto por el profesor
 */
package primera2223;

/**
operador %; es el resto de la división entera
 */
public class Ejercicio005b {
     public static void main(String arg[]){
         int x = 7;
         if ((x % 2) == 0){
             System.out.println(x + " es un número es par");
         }else
             System.out.println(x + " es un número es impar");
     }
}
