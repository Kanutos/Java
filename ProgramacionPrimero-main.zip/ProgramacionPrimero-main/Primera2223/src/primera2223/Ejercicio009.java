/*
 Hacer la tabla de multiplicar del 5
 */
package primera2223;

/**
 *
 * @author alber
 */
public class Ejercicio009 {
     public static void main(String arg[]){
        int cont, x;
        x = 5;
        for(cont = 1; cont <= 10; cont++){
            System.out.println(x + " * " + cont + " = " + (x * cont));
            if (x == 5){
            if (cont % 2 == 0);
            else   
            System.out.println("Por el culo te la hinco");
            }
        }
     }
}
