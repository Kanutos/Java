/*
 Mostrar por pantalla si un número acaba en cinco o no.
 */
package primera2223;

/**
 *
 * @author alber
 */
public class Ejercicio006 {
   public static void main(String arg[]){
         int x = 306;
         if((x % 10) == 5){
             System.out.println(x + " acaba en 5");
         }else
             System.out.println(x + " no acaba en 5");
         
   }
}
